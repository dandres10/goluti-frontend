

export interface IRefreshTokenResponseEntity {
    token: string;
}