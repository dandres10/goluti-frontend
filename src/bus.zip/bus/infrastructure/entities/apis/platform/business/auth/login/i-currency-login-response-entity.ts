export interface ICurrencyLoginResponseEntity {
    id: string;
    name: string;
    code: string;
    symbol: string;
    state: boolean;
  }