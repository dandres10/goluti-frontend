export interface ILanguageLoginResponseEntity {
  id: string;
  name: string;
  code: string;
  native_name: string;
  state: boolean;
}
