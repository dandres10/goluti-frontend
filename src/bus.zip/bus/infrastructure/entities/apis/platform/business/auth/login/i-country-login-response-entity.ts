export interface ICountryLoginResponseEntity {
  id: string;
  name: string;
  code: string;
  phone_code: string;
  state: boolean;
}
