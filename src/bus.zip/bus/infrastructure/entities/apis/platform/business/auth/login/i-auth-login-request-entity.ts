export interface IAuthLoginRequestEntity {
    email: string
    password: string
}