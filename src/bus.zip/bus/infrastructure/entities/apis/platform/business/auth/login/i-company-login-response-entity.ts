export interface ICompanyLoginResponseEntity {
  id: string;
  name: string;
  inactivity_time: number;
  nit: string;
  state: boolean;
}
