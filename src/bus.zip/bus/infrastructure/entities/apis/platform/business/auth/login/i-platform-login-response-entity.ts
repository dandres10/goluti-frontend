export interface IPlatformLoginResponseEntity {
  id: string;
  language_id: string;
  location_id: string;
  token_expiration_minutes: number;
  currency_id: string;
}
