

export interface ILogoutResponseEntity {
    message: string;
}