export interface IMenuLoginResponseEntity {
  id: string;
  name: string;
  label: string;
  description: string;
  top_id: string;
  route: string;
  state: boolean;
  icon: string;
}
