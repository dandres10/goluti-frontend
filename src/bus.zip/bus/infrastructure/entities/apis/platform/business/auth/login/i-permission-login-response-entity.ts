export interface IPermissionLoginResponseEntity {
  id: string;
  name: string;
  description: string;
  state: boolean;
}
