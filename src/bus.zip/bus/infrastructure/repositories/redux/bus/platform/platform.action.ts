import { busSlice } from "../bus.slice";


const { addPlatformAction } = busSlice.actions;

export const ACTIONS_BUS = {
  addPlatformAction,
};
