
export enum NavbarType {
    HOME = "HOME",
    DASHBOARD = "DASHBOARD"
}