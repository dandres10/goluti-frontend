export interface ILanguageReduxDTO {
  id: string;
  name: string;
  code: string;
  nativeName: string;
  state: boolean;
}
