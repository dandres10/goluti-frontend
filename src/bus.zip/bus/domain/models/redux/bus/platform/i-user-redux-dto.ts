export interface IUserReduxDTO {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    phone: string;
    state: boolean;
  }