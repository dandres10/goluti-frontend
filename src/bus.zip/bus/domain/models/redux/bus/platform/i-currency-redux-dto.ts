export interface ICurrencyReduxDTO {
    id: string;
    name: string;
    code: string;
    symbol: string;
    state: boolean;
  }