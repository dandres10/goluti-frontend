export interface ICompanyReduxDTO {
  id: string;
  name: string;
  inactivityTime: number;
  nit: string;
  state: boolean;
}
