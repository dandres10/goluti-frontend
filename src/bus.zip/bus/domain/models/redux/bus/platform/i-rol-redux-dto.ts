export interface IRolReduxDTO {
  id: string;
  name: string;
  code: string;
  description: string;
  state: boolean;
}
