export interface IPlatformInitialReduxDTO {
  id: string;
  languageId: string;
  locationId: string;
  tokenExpirationMinutes: number;
  currencyId: string;
}
