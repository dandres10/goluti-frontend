export interface IPermissionReduxDTO {
  id: string;
  name: string;
  description: string;
  state: boolean;
}
