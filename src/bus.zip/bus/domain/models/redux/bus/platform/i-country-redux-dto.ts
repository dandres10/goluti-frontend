export interface ICountryReduxDTO {
  id: string;
  name: string;
  code: string;
  phoneCode: string;
  state: boolean;
}
