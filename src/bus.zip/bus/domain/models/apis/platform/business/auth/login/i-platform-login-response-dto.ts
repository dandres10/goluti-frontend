export interface IPlatformLoginResponseDTO {
  id: string;
  languageId: string;
  locationId: string;
  tokenExpirationMinutes: number;
  currencyId: string;
}
