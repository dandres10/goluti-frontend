

export interface ILogoutResponseDTO {
    message: string;
}