export interface ICurrencyLoginResponseDTO {
    id: string;
    name: string;
    code: string;
    symbol: string;
    state: boolean;
  }