export interface ICompanyLoginResponseDTO {
  id: string;
  name: string;
  inactivityTime: number;
  nit: string;
  state: boolean;
}
