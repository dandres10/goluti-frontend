export interface IAuthLoginRequestDTO {
    email: string
    password: string
}