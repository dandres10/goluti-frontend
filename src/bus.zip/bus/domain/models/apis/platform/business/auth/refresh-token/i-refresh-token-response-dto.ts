

export interface IRefreshTokenResponseDTO {
    token: string;
}