export interface IMenuLoginResponseDTO {
  id: string;
  name: string;
  label: string;
  description: string;
  topId: string;
  route: string;
  state: boolean;
  icon: string;
}
