export interface IPermissionLoginResponseDTO {
  id: string;
  name: string;
  description: string;
  state: boolean;
}
