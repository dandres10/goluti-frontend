export interface ILanguageLoginResponseDTO {
  id: string;
  name: string;
  code: string;
  nativeName: string;
  state: boolean;
}
