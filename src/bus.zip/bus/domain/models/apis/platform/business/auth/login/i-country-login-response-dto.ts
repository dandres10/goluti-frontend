export interface ICountryLoginResponseDTO {
  id: string;
  name: string;
  code: string;
  phoneCode: string;
  state: boolean;
}
