export const KEYS_SESSION = {
    PLATFORM: "PLATFORM"
}