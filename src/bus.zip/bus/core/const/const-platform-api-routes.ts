export const CONST_PLATFORM_API_ROUTES = {
    AUTH_LOGIN: 'auth/login',
    AUTH_REFRESH_TOKEN: 'auth/refresh_token',
    AUTH_LOGOUT: 'auth/logout'
}