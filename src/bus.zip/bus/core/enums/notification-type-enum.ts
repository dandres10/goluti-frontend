export enum NOTIFICATION_TYPE_ENUM {
    DANGER = 1,
    WARNING = 2,
    SUCCESS = "SUCCESS",
    INFO = 4,
  }