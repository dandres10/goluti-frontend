export enum MESSAGE_TYPE_ENUM {
    STATIC = 1,
    TEMPORARY = 2,
    NONE = 3,
  }