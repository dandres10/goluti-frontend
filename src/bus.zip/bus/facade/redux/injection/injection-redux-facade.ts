import { PlatformReduxFacade } from "../bus/platform-redux-facade";

export class InjectionReduxFacade {
    public static PlatformReduxFacade() { return PlatformReduxFacade.getInstance() }
}